"""COPD Lung Explorer - educational hackathon prototype (not a medical system)."""
from datetime import date, timedelta
from statistics import mean
from flask import Flask, jsonify, render_template, request
from models import db, Patient, MonitoringRecord

app = Flask(__name__)
app.config["SQLALCHEMY_DATABASE_URI"] = "sqlite:///database.db"
db.init_app(app)

SYMPTOMS = {"breathlessness": "Breathlessness", "cough": "Cough", "sputum": "Sputum"}


def seed():
    if Patient.query.first():
        return
    p = Patient(name="Demo Patient", age=64, notes="Sample data for demonstration only")
    db.session.add(p)
    db.session.flush()
    rows = [  # breath, cough, sputum, activity, spo2, fev1, fvc
        (3, 3, 2, 7, 95, 1.9, 3.2), (3, 2, 3, 7, 95, 1.9, 3.2), (4, 3, 3, 6, 94, 1.9, 3.1),
        (3, 3, 2, 7, 95, 1.8, 3.2), (3, 3, 3, 7, 95, 1.9, 3.2), (4, 3, 3, 6, 94, 1.8, 3.1),
        (5, 4, 4, 5, 94, 1.8, 3.1), (6, 5, 5, 4, 93, 1.7, 3.1), (7, 6, 6, 4, 93, 1.6, 3.0),
        (7, 6, 6, 3, 92, 1.6, 3.0),
    ]
    start = date.today() - timedelta(days=len(rows) * 3)
    for i, r in enumerate(rows):
        db.session.add(MonitoringRecord(patient_id=p.id, date=start + timedelta(days=i * 3),
                                        breathlessness=r[0], cough=r[1], sputum=r[2], activity=r[3],
                                        spo2=r[4], fev1=r[5], fvc=r[6]))
    db.session.commit()


def analyse(records):
    """Compare recent entries with the person's own earlier baseline. Educational only."""
    if len(records) < 4:
        return {"status": "Not enough data", "message": "Add at least 4 entries to compare with your own baseline.",
                "changes": []}
    recent, base = records[-3:], records[:-3][:5]
    changes = []

    def avg(rs, k):
        v = [getattr(r, k) for r in rs if getattr(r, k) is not None]
        return mean(v) if v else None

    for k, label in SYMPTOMS.items():
        b, r = avg(base, k), avg(recent, k)
        if abs(r - b) >= 1.5:
            changes.append({"name": label, "direction": "up" if r > b else "down", "baseline": round(b, 1), "recent": round(r, 1)})
    b, r = avg(base, "activity"), avg(recent, "activity")
    if abs(r - b) >= 1.5:
        changes.append({"name": "Activity", "direction": "up" if r > b else "down", "baseline": round(b, 1), "recent": round(r, 1)})
    b, r = avg(base, "fev1"), avg(recent, "fev1")
    if b and r and abs(r - b) / b >= 0.10:
        changes.append({"name": "FEV1", "direction": "up" if r > b else "down", "baseline": round(b, 2), "recent": round(r, 2)})
    n = len(changes)
    if n == 0:
        status, msg = "Stable trend", "Recent entries are similar to the person's earlier measurements."
    elif n < 3:
        status, msg = "Change from baseline", "Recent symptoms differ from the patient's previous measurements."
    else:
        status, msg = "Needs monitoring", ("Several values differ from the earlier baseline. This is a simple trend comparison, "
                                           "not a diagnosis or prediction - consider discussing changes with a healthcare professional.")
    return {"status": status, "message": msg, "changes": changes}


# ---------- pages ----------
for path, tpl in [("/", "index.html"), ("/explorer", "explorer.html"), ("/small-airways", "small_airways.html"),
                  ("/emphysema", "emphysema.html"), ("/chronic-bronchitis", "chronic_bronchitis.html"),
                  ("/monitoring", "monitoring.html"), ("/analysis", "analysis.html"),
                  ("/dashboard", "dashboard.html"), ("/about", "about.html")]:
    app.add_url_rule(path, tpl, (lambda t: lambda: render_template(t))(tpl))


# ---------- API ----------
@app.route("/api/patient", methods=["GET", "POST"])
def api_patient():
    p = Patient.query.first()
    if request.method == "POST":
        d = request.get_json(force=True)
        p.name, p.age, p.notes = d.get("name", p.name), d.get("age", p.age), d.get("notes", p.notes)
        db.session.commit()
    return jsonify(p.to_dict())


@app.route("/api/monitoring", methods=["GET", "POST"])
def api_monitoring():
    p = Patient.query.first()
    if request.method == "POST":
        d = request.get_json(force=True)
        def num(k, lo, hi, required=True):
            v = d.get(k)
            if v in (None, ""):
                if required:
                    raise ValueError(f"{k} is required")
                return None
            v = float(v)
            if not lo <= v <= hi:
                raise ValueError(f"{k} must be between {lo} and {hi}")
            return v
        try:
            rec = MonitoringRecord(patient_id=p.id, breathlessness=num("breathlessness", 0, 10),
                                   cough=num("cough", 0, 10), sputum=num("sputum", 0, 10),
                                   activity=num("activity", 0, 10), spo2=num("spo2", 50, 100, False),
                                   fev1=num("fev1", 0.1, 8), fvc=num("fvc", 0.1, 10))
        except ValueError as e:
            return jsonify(error=str(e)), 400
        db.session.add(rec)
        db.session.commit()
        return jsonify(rec.to_dict()), 201
    return jsonify([r.to_dict() for r in p.records])


@app.route("/api/analysis")
def api_analysis():
    return jsonify(analyse(Patient.query.first().records))


with app.app_context():
    db.create_all()
    seed()

if __name__ == "__main__":
    app.run(debug=True)
