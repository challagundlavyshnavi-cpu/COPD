// Conceptual SVG illustrations. Educational only.
function airwaySVG(narrow, inflamed) {
  const outer = 70, wall = 8 + (inflamed ? narrow * 0.22 : 0);
  const lumen = Math.max(6, (outer - wall) * (1 - narrow / 100));
  const wallColor = inflamed ? (narrow > 55 ? "#d64545" : "#f0902b") : "#f2b8a8";
  return `<svg viewBox="0 0 160 160" width="160"><circle cx="80" cy="80" r="${outer + 8}" fill="${wallColor}"/>
    <circle cx="80" cy="80" r="${lumen}" fill="#e8f3fc"/></svg>`;
}
function alveoliSVG(damaged) {
  let s = '<svg viewBox="0 0 240 160" width="240">', i = 0;
  const cells = damaged
    ? [[60,60,34],[150,50,42],[95,115,38],[190,110,32]]
    : [[35,35,18],[80,35,18],[125,35,18],[170,35,18],[57,75,18],[102,75,18],[147,75,18],[192,75,18],[35,115,18],[80,115,18],[125,115,18],[170,115,18]];
  cells.forEach(([x, y, r]) => { s += `<circle cx="${x}" cy="${y}" r="${r}" fill="#e8f3fc" stroke="${damaged ? '#d64545' : '#3b9ae1'}" stroke-width="${damaged ? 1.5 : 3}" ${damaged ? 'stroke-dasharray="6 4"' : ''}/>`; i++; });
  return s + "</svg>";
}
function mucusSVG(level) {
  const lumen = 60 * (1 - level / 100 * 0.85);
  return `<svg viewBox="0 0 160 160" width="160"><circle cx="80" cy="80" r="76" fill="#f2b8a8"/>
    <circle cx="80" cy="80" r="62" fill="#c9d64a" opacity="${level ? 0.9 : 0}"/>
    <circle cx="80" cy="80" r="${Math.max(4, lumen)}" fill="#e8f3fc"/></svg>`;
}
function renderViz(el) {
  const t = el.dataset.viz;
  if (t === "airway") el.innerHTML = airwaySVG(+el.dataset.narrow, el.dataset.inflamed === "1");
  if (t === "alveoli") el.innerHTML = alveoliSVG(el.dataset.damaged === "1");
  if (t === "mucus") el.innerHTML = mucusSVG(+el.dataset.level);
}
document.querySelectorAll("[data-viz]").forEach(renderViz);

const ns = document.getElementById("narrowSlider");
if (ns) {
  const upd = () => {
    const v = +ns.value, live = document.getElementById("airwayLive");
    live.dataset.narrow = v; renderViz(live);
    document.getElementById("narrowVal").textContent = v;
    document.getElementById("diamVal").textContent = (100 - v) + "% of normal (illustrative)";
    const flow = Math.round(Math.pow((100 - v) / 100, 2) * 100); // narrower tube -> disproportionately less flow (conceptual)
    document.getElementById("flowVal").textContent = flow + "% (conceptual)";
    const b = document.getElementById("flowBar"); b.style.width = flow + "%";
    b.className = "progress-bar " + (flow > 60 ? "bg-success" : flow > 30 ? "bg-warning" : "bg-danger");
  };
  ns.oninput = upd; upd();
}
const ms = document.getElementById("mucusSlider");
if (ms) {
  const upd = () => {
    const v = +ms.value, live = document.getElementById("mucusLive");
    live.dataset.level = v; renderViz(live);
    document.getElementById("mucusVal").textContent = v;
    document.getElementById("lumenVal").textContent = Math.round(100 - v * 0.85) + "% open (illustrative)";
  };
  ms.oninput = upd; upd();
}
