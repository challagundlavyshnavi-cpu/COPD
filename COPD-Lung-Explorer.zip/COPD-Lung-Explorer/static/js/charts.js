let historyChart;
function drawHistory(rows) {
  const ctx = document.getElementById("historyChart");
  if (!ctx) return;
  const ds = (label, key, color) => ({ label, data: rows.map(r => r[key]), borderColor: color, tension: .3 });
  if (historyChart) historyChart.destroy();
  historyChart = new Chart(ctx, { type: "line",
    data: { labels: rows.map(r => r.date), datasets: [
      ds("Breathlessness", "breathlessness", "#d64545"), ds("Cough", "cough", "#f0902b"),
      ds("Sputum", "sputum", "#2e9e5b"), ds("Activity", "activity", "#3b9ae1")] },
    options: { scales: { y: { min: 0, max: 10 } } } });
}
async function initMonitoring() {
  drawHistory(await api("/api/monitoring"));
  document.getElementById("recForm").onsubmit = async e => {
    e.preventDefault();
    const body = Object.fromEntries(new FormData(e.target));
    const msg = document.getElementById("formMsg");
    try {
      await api("/api/monitoring", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) });
      msg.innerHTML = '<span class="text-success">Saved.</span>';
      drawHistory(await api("/api/monitoring"));
    } catch (err) { msg.innerHTML = `<span class="text-danger">${err.message}</span>`; }
  };
}
async function initAnalysis() {
  const a = await api("/api/analysis");
  const cls = { "Stable trend": "green", "Change from baseline": "yellow", "Needs monitoring": "red" }[a.status] || "yellow";
  const items = a.changes.map(c => `<li>${c.name} ${arrow(c.direction)} <small class="text-muted">(baseline ${c.baseline} → recent ${c.recent})</small></li>`).join("");
  document.getElementById("analysisBox").innerHTML =
    `<h4 class="trend-${cls}">${a.status}</h4><p>${a.message}</p><ul>${items}</ul>
     <small class="text-muted">Educational trend comparison — not a diagnosis or prediction.</small>`;
}
async function initDashboard() {
  const [p, rows, a] = await Promise.all([api("/api/patient"), api("/api/monitoring"), api("/api/analysis")]);
  const l = rows[rows.length - 1];
  const cls = { "Stable trend": "green", "Change from baseline": "yellow", "Needs monitoring": "red" }[a.status] || "yellow";
  document.getElementById("tPatient").textContent = `${p.name}, ${p.age}`;
  if (l) {
    document.getElementById("tSymp").textContent = `${l.breathlessness} / ${l.cough} / ${l.sputum}`;
    const r = document.getElementById("tRatio"); r.textContent = l.ratio; r.className = "trend-" + cls;
    document.getElementById("tAct").textContent = l.activity + "/10";
    document.getElementById("tSpo2").textContent = l.spo2 ? l.spo2 + "%" : "not entered";
    const aw = document.getElementById("dAirway"); aw.dataset.narrow = l.breathlessness * 8; renderViz(aw);
    const mu = document.getElementById("dMucus"); mu.dataset.level = l.sputum * 10; renderViz(mu);
  }
  drawHistory(rows);
}
