# COPD Lung Explorer
**Educational prototype — not a medical diagnostic or treatment system.**

## Run in VS Code
1. Open the `COPD-Lung-Explorer` folder in VS Code.
2. Terminal: `python -m venv venv`, then activate it
   (Windows: `venv\Scripts\activate`, macOS/Linux: `source venv/bin/activate`).
3. `pip install -r requirements.txt`
4. `python app.py` and open http://127.0.0.1:5000
`database.db` (SQLite, in `instance/`) is created on first run with 10 sample entries for a "Demo Patient".
Bootstrap, icons and Chart.js load from a CDN, so an internet connection is needed in the browser.

## Files
- `app.py` – Flask routes, JSON APIs, sample-data seeding, simple baseline-comparison logic.
- `models.py` – SQLAlchemy `Patient` and `MonitoringRecord`.
- `templates/base.html` – navbar, footer disclaimer, script includes. Other pages extend it.
- `templates/_small.html`, `_emph.html`, `_bron.html` – the three explorer sections (shared by `/explorer` and the single-topic pages).
- `templates/monitoring|analysis|dashboard|about.html` – remaining pages.
- `static/css/style.css` – theme (dark blue, light blue, white, green, orange, red), cards, animations.
- `static/js/main.js` – fetch helper. `lung.js` – SVG airway/alveoli/mucus drawings and sliders. `charts.js` – Chart.js history, analysis and dashboard logic.

## Architecture
Browser (Bootstrap + JS + Chart.js) → Flask routes (pages) and `/api/patient`, `/api/monitoring`, `/api/analysis` (JSON) → SQLAlchemy → SQLite.

## Analysis logic (educational)
Baseline = earlier entries (up to 5); recent = last 3. A value is flagged if symptoms/activity move ≥1.5 points or FEV1 moves ≥10%.
0 flags → Stable trend; 1–2 → Change from baseline; 3+ → Needs monitoring. No diagnosis, no prediction, no medication advice.

## UI descriptions
- Home: dark-blue gradient hero, "Explore COPD" button, three feature cards.
- Explorer: airway trio (healthy/inflamed/narrowed) with Airway Narrowing slider; alveoli comparison with two breathing animations (one keeps some air trapped); airway with Mucus Level slider.
- Monitoring: slider form on the left, Chart.js history on the right.
- Analysis: coloured status, explanation, list such as Breathlessness ↑, Cough ↑, Sputum ↑, Activity ↓.
- Dashboard: tiles (patient, symptoms, FEV1/FVC, activity, SpO₂), three visuals, history chart.

## 2-minute demo
0:00 Home and disclaimer → 0:20 Small airways slider → 0:40 Emphysema animation → 1:00 Mucus slider → 1:15 Monitoring: add an entry, chart updates → 1:35 Analysis: "differs from previous measurements" → 1:50 Dashboard, stress it is educational only.
