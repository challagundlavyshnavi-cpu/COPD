from datetime import date
from flask_sqlalchemy import SQLAlchemy

db = SQLAlchemy()


class Patient(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(80), default="Demo Patient")
    age = db.Column(db.Integer)
    notes = db.Column(db.String(300), default="")
    records = db.relationship("MonitoringRecord", backref="patient", order_by="MonitoringRecord.date")

    def to_dict(self):
        return dict(id=self.id, name=self.name, age=self.age, notes=self.notes)


class MonitoringRecord(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    patient_id = db.Column(db.Integer, db.ForeignKey("patient.id"), nullable=False)
    date = db.Column(db.Date, default=date.today)
    breathlessness = db.Column(db.Float)  # 0-10
    cough = db.Column(db.Float)           # 0-10
    sputum = db.Column(db.Float)          # 0-10
    activity = db.Column(db.Float)        # 0-10 (10 = very active)
    spo2 = db.Column(db.Float, nullable=True)
    fev1 = db.Column(db.Float)            # litres
    fvc = db.Column(db.Float)             # litres

    def to_dict(self):
        ratio = round(self.fev1 / self.fvc, 2) if self.fev1 and self.fvc else None
        return dict(id=self.id, date=self.date.isoformat(), breathlessness=self.breathlessness,
                    cough=self.cough, sputum=self.sputum, activity=self.activity, spo2=self.spo2,
                    fev1=self.fev1, fvc=self.fvc, ratio=ratio)
